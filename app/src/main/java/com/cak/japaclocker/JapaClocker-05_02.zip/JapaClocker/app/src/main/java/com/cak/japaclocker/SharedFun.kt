package com.cak.japaclocker

class SharedFun {
}